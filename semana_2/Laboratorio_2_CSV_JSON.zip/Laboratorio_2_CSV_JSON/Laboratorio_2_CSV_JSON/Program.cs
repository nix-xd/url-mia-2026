﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

class Program
{
    private string rutaCsv = "estudiantes.csv";
    private string rutaJson = "estudiantes.json";

    public void Proceso()
    {
        List<Estudiante> listaEstudiantes = new List<Estudiante>();

        using (StreamReader reader = new StreamReader(rutaCsv))
        {
            reader.ReadLine(); 

            string? linea;

            while ((linea = reader.ReadLine()) != null)
            {
                string[] datos = linea.Split(',');

                if (datos.Length == 3)
                {
                    Estudiante nuevoEstudiante = new Estudiante
                    {
                        Id = int.Parse(datos[0]), Nombre = datos[1], Carrera = datos[2]
                    };

                    listaEstudiantes.Add(nuevoEstudiante);
                }
            }
        }

        foreach (var est in listaEstudiantes)
        {
            Console.WriteLine($"{est.Id} - {est.Nombre} - {est.Carrera}");
        }

        var opcionesJson = new JsonSerializerOptions { WriteIndented = true };

        string jsonTexto = JsonSerializer.Serialize(listaEstudiantes, opcionesJson);

        File.WriteAllText(rutaJson, jsonTexto);

        Console.WriteLine("Se creo el archivo estudiantes.json");
    }
    static void Main(string[] args)
    {
        Program program = new Program();

        program.Proceso();
    }
}
